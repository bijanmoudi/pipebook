export { default } from './Info';
