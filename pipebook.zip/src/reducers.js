import { combineReducers } from 'redux';
import ListPage from './containers/ListPage/reducer';

const reducer = combineReducers({
	ListPage
});

export default reducer;
