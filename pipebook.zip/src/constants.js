export const API_TOKEN = 'd8ecd5215884b7f537b4b2b3c51e212c79921bcf';
export const API_URL = 'https://api.pipedrive.com/v1/';
export const API_VARIABLE__START = 'start';
export const API_VARIABLE__LIMIT = 'limit';
export const API_VARIABLE__TOKEN = 'api_token';
export const API_VARIABLE__TERM = 'term';
export const API_VARIABLE__SORT = 'sort';
export const LIST__LIMIT = 15;
export const LIST__GROUP_COUNT = 3;

export * from './containers/ListPage/constants';
